#by AsiCloud


from Musicland.core.bot import Nand
from Musicland.core.dir import dirr

from Musicland.core.userbot import Userbot
from Musicland.misc import dbb, heroku

from .logging import LOGGER

dirr()

dbb()
heroku()

app = Nand()
userbot = Userbot()


from .platforms import *

Apple = AppleAPI()
Carbon = CarbonAPI()
SoundCloud = SoundAPI()
Spotify = SpotifyAPI()
Resso = RessoAPI()
Telegram = TeleAPI()
YouTube = YouTubeAPI()


#by AsiCloud
