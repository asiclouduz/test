# by AsiCloud

from typing import Union

from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQueryResultPhoto,
    Message
)
from youtubesearchpython.__future__ import VideosSearch

from Musicland import app
from Musicland.utils.inlinequery import answer
from Musicland.utils.database import get_lang
from strings import get_string
from config import BANNED_USERS


@app.on_inline_query(~BANNED_USERS)
async def inline_query_handler(client, query):
    language = await get_lang(query.from_user.id)
    _ = get_string(language)
    
    text = query.query.strip().lower()
    answers = []
    
    if text.strip() == "":
        try:
            await client.answer_inline_query(query.id, results=answer, cache_time=10)
        except:
            return
    else:
        a = VideosSearch(text, limit=20)
        result = (await a.next()).get("result")
        for x in range(15):
            title = (result[x]["title"]).title()
            duration = result[x]["duration"]
            views = result[x]["viewCount"]["short"]
            thumbnail = result[x]["thumbnails"][0]["url"].split("?")[0]
            channellink = result[x]["channel"]["link"]
            channel = result[x]["channel"]["name"]
            link = result[x]["link"]
            published = result[x]["publishedTime"]
            
            # Tarjima qilinadigan matnlar endi lug'atdan olinadi
            description = f"{views} | {duration} {_['inline_minutes']} | {channel} | {published}"
            
            buttons = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            text=_["inline_youtube"],
                            url=link,
                        )
                    ],
                ]
            )
            
            searched_text = _["inline_search"].format(
                title=title,
                link=link,
                duration=duration,
                views=views,
                channel=channel,
                channellink=channellink,
                published=published,
                appname=app.name
            )
            
            answers.append(
                InlineQueryResultPhoto(
                    photo_url=thumbnail,
                    title=title,
                    thumb_url=thumbnail,
                    description=description,
                    caption=searched_text,
                    reply_markup=buttons,
                )
            )
        try:
            return await client.answer_inline_query(query.id, results=answers)
        except:
            return